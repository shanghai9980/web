<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Trailer Website</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="icon" type="image/jpg" href="Picture/Picture Web Anime/Title Web.jpg" />
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/jquery-func.js"></script>
<!--[if IE 6]><link rel="stylesheet" href="css/ie6.css" type="text/css" media="all" /><![endif]-->
</head>

<body>
<div class="head">
         <h2>PHIM HÀNH ĐỘNG</h2>
          <p class="text-right"><a href="#">See all</a></p>
        </div>
        <div class="movie">
          <div class="movie-image"><a href="#"><span class="play" style="display: inline;"><span class="name">The Boss Baby</span></span> <img src="Picture/Picture Movie/The Boss Baby (2).jpg" alt=""></a></div>
          <div class="rating">
            <p>RATING</p>
            <div class="stars">
              <div class="stars-in"> </div>
            </div>
            <span class="comments">95</span> </div>
        </div>
        <div class="movie">
          <div class="movie-image"> <a href="#"><span class="play" style="display: none;"><span class="name">Cướp viển vùng Caribbe (P5)</span></span> <img src="Picture/Picture Movie/Caribbe P5.jpg" alt=""></a> </div>
          <div class="rating">
            <p>RATING</p>
            <div class="stars">
              <div class="stars-in"> </div>
            </div>
            <span class="comments">35</span> </div>
        </div>
<!--        <div class="movie">
          <div class="movie-image"><a href="#"> <span class="play" style="display: none;"><span class="name">Guardians Of The Galaxy 2</span></span><img src="Picture/Picture Movie/Guardians Of The Galaxy 2.jpg" alt=""></a> </div>
          <div class="rating">
            <p>RATING</p>
            <div class="stars">
              <div class="stars-in"> </div>
            </div>
            <span class="comments">55</span> </div>
        </div>
        <div class="movie">
          <div class="movie-image"><a href="#"> <span class="play"><span class="name">Assassin's Creed</span></span><img src="Picture/Picture Movie/assassins-creed-movie (2).jpg" alt=""></a> </div>
          <div class="rating">
            <p>RATING</p>
            <div class="stars">
              <div class="stars-in"> </div>
            </div>
            <span class="comments">12</span> </div>
        </div>

       <div class="cl2">&nbsp;</div>

        
        <div class="movie">
          <div class="movie-image"> <a href="#"><span class="play"><span class="name">Justice League</span></span><img src="Picture/Picture Movie/Justice League.jpg" alt="" /></a> </div>
          <div class="rating">
            <p>RATING</p>
            <div class="stars">
              <div class="stars-in"> </div>
            </div>
            <span class="comments">90</span> </div>
        </div>
        <div class="movie">
          <div class="movie-image"> <a href="#"><span class="play"><span class="name">Dr.Strange</span></span> <img src="Picture/Picture Movie/Dr.Strange.jpg" alt="" /></a> </div>
          <div class="rating">
            <p>RATING</p>
            <div class="stars">
              <div class="stars-in"> </div>
            </div>
            <span class="comments">70</span> </div>
        </div>
        <div class="movie">
          <div class="movie-image"><a href="#"> <span class="play"><span class="name">Logan</span></span> <img src="Picture/Picture Movie/Logan.jpg" alt="" /></a> </div>
          <div class="rating">
            <p>RATING</p>
            <div class="stars">
              <div class="stars-in"> </div>
            </div>
            <span class="comments">55</span> </div>
        </div>
        <div class="movie">
          <div class="movie-image"> <a href="#"><span class="play"><span class="name">Fantastic Beasts and Where to Find Them</span></span> <img src="Picture/Picture Movie/Fantastic Beasts and Where to Find Them.jpg" alt="" /></a> </div>
          <div class="rating">
            <p>RATING</p>
            <div class="stars">
              <div class="stars-in"> </div>
            </div>
            <span class="comments">33</span> </div>
        </div>

       <div class="cl">&nbsp;</div>

        
        <div class="movie">
          <div class="movie-image"> <a href="#"><span class="play"><span class="name">Justice League</span></span> <img src="Picture/Picture Movie/Justice League.jpg" alt="" /></a> </div>
          <div class="rating">
            <p>RATING</p>
            <div class="stars">
              <div class="stars-in"> </div>
            </div>
            <span class="comments">100</span> </div>
        </div>
        <div class="movie">
          <div class="movie-image"> <a href="#"><span class="play"><span class="name">Dr.Strange</span></span> <img src="Picture/Picture Movie/Dr.Strange.jpg" alt="" /></a> </div>
          <div class="rating">
            <p>RATING</p>
            <div class="stars">
              <div class="stars-in"> </div>
            </div>
            <span class="comments">90</span> </div>
        </div>
        <div class="movie">
          <div class="movie-image"> <a href="#"><span class="play"><span class="name">SING</span></span> <img src="Picture/Picture Movie/Sing.jpg" alt="" /></a> </div>
          <div class="rating">
            <p>RATING</p>
            <div class="stars">
              <div class="stars-in"> </div>
            </div>
            <span class="comments">70</span> </div>
        </div>
        <div class="movie">
          <div class="movie-image"> <a href="#"><span class="play"><span class="name">Death Note: Light Up The New World</span></span> <img src="Picture/Picture Movie/Death Note.jpg" alt="" /></a> </div>
          <div class="rating">
            <p>RATING</p>
            <div class="stars">
              <div class="stars-in"> </div>
            </div>
            <span class="comments">65</span> </div>
        </div>-->

       <div class="cl">&nbsp;</div>
       
</body>
</html>