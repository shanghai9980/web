<?php 
				$qg="";$quocgia="";
					if($row["macountry"]=="my")	{$qg="my";$quocgia="Mỹ";}
					if($row["macountry"]=="hanquoc")	{$qg="hanquoc";$quocgia="Hàn Quốc";}
					if($row["macountry"]=="vietnam")	{$qg="vietnam";$quocgia="Việt Nam";}
					if($row["macountry"]=="trungquoc")	{$qg="trungquoc";$quocgia="Trung Quốc";}
					if($row["macountry"]=="nhatban")	{$qg="nhatban";$quocgia="Nhật Bản";}

			?>