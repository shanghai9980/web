
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />


</head>

<body>
<div class="head">
         <h2>PHIM LẺ MỚI CẬP NHẬT</h2>
          <p class="text-right"><a href="#">See all</a></p>
        </div>
       <?php include "newphimle.php";?>	

       <div class="cl2">&nbsp;</div>

        <div class="head">
          <h2>PHIM BỘ MỚI CẬP NHẬT</h2>
          <p class="text-right"><a href="TOP RATED.html">See all</a></p>
        </div>
        <?php include "newphimbo.php";?>

       <div class="cl">&nbsp;</div>

        <div class="head">
          <h2>PHIM MỸ MỚI CẬP NHẬT</h2>
          <p class="text-right"><a href="MOST COMMENTED.html">See all</a></p>
        </div>
        <?php include "newphimmy.php";?>

       <div class="cl">&nbsp;</div>
       
</body>
</html>