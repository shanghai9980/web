

<div id="jssor_1" style="position: relative; margin: 0 auto 20px auto; top: 20px; left: 0px; width: 600px; height: 300px; overflow: hidden; visibility: hidden;z-index:1;">
	    <!-- Loading Screen -->
	    <div data-u="loading" style="position: absolute; top: 0px; left: 0px;">
	      <div style="filter: alpha(opacity=70); opacity: 0.7; position: absolute; display: block; top: 0px; left: 0px; width: 100%; height: 100%;"></div>
	      <div style="position:absolute;display:block;background:url('img/loading.gif') no-repeat center center;top:0px;left:0px;width:100%;height:100%;"></div>
        </div>
	    <div data-u="slides" style="cursor: default; position: relative; top: 0px; left: 0px; width: 600px; height: 300px; overflow: hidden;">
			<div data-p="112.50" style="display: none;"><a title="The Walking Dead (Season 7)" href="index.php?mod=phimbo&ac=detailphimbo&id=8"><img data-u="image" src="Picture/Picture Movie/the-walking-dead-season-7.jpg" /></a></div>
	      	<div data-p="112.50" style="display: none;"><a title="The Boss Baby" href="index.php?mod=newphimle&id=11"><img data-u="image" src="Picture/Picture Movie/The Boss Baby.jpg" /></a></div>
	     	<div data-p="112.50" style="display: none;"><a title="Assassin's Creed" href="index.php?mod=newphimle&id=9"><img data-u="image" src="Picture/Picture Movie/assassins-creed-movie.jpg" /></a></div>
	     	<div data-p="112.50" style="display: none;"><a title="Tales of Zestiria the X 2nd Season" href="index.php?mod=newphimbo&id=10"><img data-u="image" src="Picture/Picture Movie/tales-zestiria.jpg" /></a></div>

        </div>
	    <!-- Bullet Navigator -->
	    <div data-u="navigator" class="jssorb05" style="bottom:16px;right:16px;" data-autocenter="1">
	      <!-- bullet navigator item prototype -->
	      <div data-u="prototype" style="width:16px;height:16px;"></div>
        </div>
	    <!-- Arrow Navigator -->
	    <span data-u="arrowleft" class="jssora12l" style="top:0px;left:0px;width:30px;height:46px;" data-autocenter="2"></span><span data-u="arrowright" class="jssora12r" style="top:0px;right:0px;width:30px;height:46px;" data-autocenter="2"></span><a href="http://www.jssor.com" style="display:none">Slideshow Maker</a></div>
	  <script>jssor_1_slider_init();</script><!-- #endregion Jssor Slider End --></script>